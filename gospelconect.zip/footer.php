 <!-- Footer-->
  <div class="py-5 bg-light">
    <div class="container">
      <hr>
      <div class="row">
        <div class="col-lg-3 text-center">
          <h5>Gospel Conect</h5>
          <ul class="contact-info list-unstyled">
            <li><a href="mailto:sales@landy.com" class="text-dark">comercial@gospelconect.com.br</a></li>
            <li><a href="tel:123456789" class="text-dark">(41) 98423-0675</a></li>
          </ul>
          <p class="text-muted">Trabalhando com amor.</p>
        </div>
        <div class="col-lg-3 novo text-center">
          <h5>Categorias</h5>
          <ul class="links list-unstyled">
            <li> <a href="#" class="text-muted">Blog</a></li>
            <li> <a href="#" class="text-muted">Notícias</a></li>
            <!--<li> <a href="#" class="text-muted">Resenha </a><small>novo</small></li>
            <li> <a href="#" class="text-muted">Missões Já </a><small>novo</small></li>-->
          </ul>
        </div>
        <div class="col-lg-3 text-center">
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo get_theme_mod( 'm2_logo' ); ?>" class="img-responsive" title="Gospel Conect"></a>
        </div>
        <div class="col-lg-3 text-center">
          <h5>Links Importantes</h5>
          <ul class="links list-unstyled align-center">
            <li> <a href="https://www.biblegateway.com/" class="text-muted">BiblieGateway</a></li>
            <li> <a href="https://biblia.com/" class="text-muted">Biblia.com</a></li>
            <li> <a href="https://tuapalavra.com.br/" class="text-muted">Tua Palavra</a></li>
            <li> <a href="https://www.theologyofwork.org/" class="text-muted">theologyofwork</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="py-3 bg-dark text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-7 text-center text-md-left">
          <p class="mb-md-0">&copy; 2019 Gospel Conect. Todos os Direitos Reservados. </p>
        </div>
        <div class="col-md-5 text-center text-md-right">
         <!-- <p class="mb-0">Template By <a href="https://bootstrapious.com/" class="external text-white">Bootstrapious</a> </p>-->
        </div>
      </div>
    </div>
  </div>

    <!-- JavaScript (Opcional) -->
    <!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/e3a660d818.js" crossorigin="anonymous"></script>
<?php wp_footer(); ?>
  </body>
</html>