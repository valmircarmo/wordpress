<?php get_header(); ?>

<div class="pagina">
<hr class="linha">
<?php if (have_posts()): while (have_posts()) : the_post();?>

<div class="container">
<?php wp_custom_breadcrumbs(); ?>
<div class="row">

<div class="col-lg-8 text-justify">



              <h1><?php the_title();?></h1>

                <hr>

                <p><span class="glyphicon glyphicon-time"></span><?php the_time('j \d\e F \d\e Y') ?> |  Publicado por <?php the_author_posts_link(); ?> | Categoria <?php the_category(', ') ?> | Visitas <?php if(function_exists('the_views')) { the_views(); } ?></p>
                <hr>
                <!-- Preview Image -->

			                  <?php
			if (has_post_thumbnail()) {
			the_post_thumbnail('melgus', array('class' => 'img-thumbnail'));
			}else{
			echo '<img src="'.get_bloginfo('template_directory').'/images/logogc.png" />';
			}
			?>
           <p class="text-justify"><?php the_content();?></p>

           <h4></h4>

</div>

<div class="col-lg-4">
	<?php dynamic_sidebar('sidebar'); ?>
</div>





</div>

</div>

			  <?php endwhile; else:?>
			  <?php endif;?>

</div>












<?php get_footer(); ?>