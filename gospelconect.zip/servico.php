<div class="servico py-1">
<div class="container">
  <h2>Nossos Produtos <i class="fas fa-angle-double-right"></i></h2>
  <div class="row">
           <?php query_posts('showposts=3&category_name=servicos');?>
     <?php if (have_posts()): while (have_posts()) : the_post();?>
   <div class="col-lg">
      <h3><?php the_title(); ?></h3>
    
     <a href="<?php the_Permalink()?>">
      <?php
if (has_post_thumbnail()) {
the_post_thumbnail('melgus', array('class' => 'img-thumbnail'));
}else{
echo '<img src="'.get_bloginfo('template_directory').'/images/logogc.png" />';
}
?>
   </a>

       <p class="branco"><?php the_excerpt_rereloaded(20, '');?></p>
      <a class="btn btn-primary" href="<?php the_Permalink()?>" role="button"><i class="fas fa-book-reader"></i> Leia</a>
    </div>
     <?php endwhile; else:?>
Em breve teremos publicações
    <?php endif;?>
  
</div>
</div>

</div>