<?php

// marca automatica
function m2_customize_register( $wp_customize ) {
    $wp_customize->add_setting( 'm2_logo' ); // Add setting for logo uploader
         
    // Add control for logo uploader (actual uploader)
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'm2_logo', array(
        'label'    => __( 'Logo footer do Site', 'm2' ),
        'section'  => 'title_tagline',
        'settings' => 'm2_logo',
    ) ) );
}
add_action( 'customize_register', 'm2_customize_register' );

?>