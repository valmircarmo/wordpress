<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Meta tags Obrigatórias -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="" name="keywords">
    <meta content="" name="description">
        <!-- Favicons -->
    <link href="images/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
   <style type="text/css" media="screen">
          @import url( <?php bloginfo('stylesheet_url'); ?> );
          </style>
      <!-- Bootstrap CSS -->
    <link href="<?php bloginfo('template_directory'); ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php bloginfo('template_directory'); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei&display=swap" rel="stylesheet">
    <title>
      <?php



    global $page, $paged;



    wp_title( '|', true, 'right' );



    bloginfo( 'name' );



    $site_description = get_bloginfo( 'description', 'display' );



    if ( $site_description && ( is_home() || is_front_page() ) )



        echo " | $site_description";



 



    if ( $paged >= 2 || $page >= 2 )



        echo ' | ' . sprintf( __( 'Page %s', 'starkers' ), max( $paged, $page ) );


?>

    </title>
        <?php wp_head(); ?>
  </head>
  <body>
    <div class="menu-topo">
<div class="container">
 <div class="row">
    <div class="col-lg-4 align-center"></div>
 <div class="col-lg-5 align-center"></div>
  <div class="col-lg-3"> <i class="fas fa-envelope fa-1x"></i> contato@gospelconect.com.br</div>
</div>
</div>
</div>
<div class="container" align="center">
 <div class="row">

  <div class="col-lg-4 justify-content-center my-1">
     <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo get_theme_mod( 'm1_logo' ); ?>" class="img-responsive" title="Gospel Conect"></a>
  </div>

<div class="col-lg-4 justify-content-center my-1 whatsapp">
  <a href="https://api.whatsapp.com/send?1=pt_BR&phone=5541984230675"><i class="fab fa-whatsapp fa-6x" title="Clique no icone para fazer no whatsapp"></i></a>
</div>

<div class="col-lg-4 align-center baixar">
  <i class="fab fa-facebook-square fa-3x facebook" title="Visite nossa pagina no facebook"></i>
  <i class="fab fa-facebook-messenger fa-3x messanger" title="Clique no icone para fazer no Messenger"></i>
  <i class="fab fa-instagram fa-3x instagram" title="Visite nosso Instagram"></i>
  <i class="fab fa-youtube-square fa-3x youtube" title="Siga-nos no Youtube"></i>

</div>

 </div>
</div>
<!--Chama o content do menu-->
<?php include (TEMPLATEPATH . '/menu.php'); ?>