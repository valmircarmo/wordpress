<?php get_header(); ?>



<!--Chama o Banner-->
<?php include (TEMPLATEPATH . '/banner.php'); ?>

<!--Chama o Servico-->
<?php include (TEMPLATEPATH . '/servico.php'); ?>

<!--Chama o Conteudo-->
<?php include (TEMPLATEPATH . '/conteudo.php'); ?>

<?php get_footer(); ?>