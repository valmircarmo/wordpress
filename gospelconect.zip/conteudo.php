<div class=" diario my-1">

<div class="container">
    <hr>
    <h2 class="p-3 mb-2 bg-dark text-white font" align="center"><i class="fas fa-book-open"></i> Nosso Diario de Livros <i class="fas fa-book-open"></i></h2>
  <div class="row">

       <?php query_posts('showposts=2&category_name=blog');?>
     <?php if (have_posts()): while (have_posts()) : the_post();?>
   <div class="col-lg-3 my-1">
      
 
      <?php
if (has_post_thumbnail()) {
the_post_thumbnail('img-thumbnail', array('class' => 'img-thumbnail'));
}else{
echo '<img src="'.get_bloginfo('template_directory').'/images/logogc.png" />';
}
?> 
      <h4><?php the_title(); ?></h4>
      <p><?php the_excerpt_rereloaded(20, '');?></p>
      <a class="btn btn-primary" href="<?php the_Permalink()?>" role="button"><i class="fas fa-book-reader"></i> Continue Lendo</a>
    </div>

     <?php endwhile; else:?>
Em breve teremos publicações
    <?php endif;?>
 
      <?php query_posts('showposts=1&category_name=blog');?>
     <?php if (have_posts()): while (have_posts()) : the_post();?>
  <div class="col-lg-6 my-1">
      
      <a href="<?php the_Permalink()?>">
      <?php
if (has_post_thumbnail()) {
the_post_thumbnail('img-thumbnail', array('class' => 'img-thumbnail'));
}else{
echo '<img src="'.get_bloginfo('template_directory').'/images/logogc.png" />';
}
?>
</a>
    </div>
       <?php endwhile; else:?>
Você ainda não publicou
    <?php endif;?>
</div>
</div>

</div>